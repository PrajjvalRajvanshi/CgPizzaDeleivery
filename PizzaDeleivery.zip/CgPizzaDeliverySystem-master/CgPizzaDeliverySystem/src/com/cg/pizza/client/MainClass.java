package com.cg.pizza.client;

import java.util.Scanner;

import com.cg.pizza.exceptions.InvalidEmailIdException;
import com.cg.pizza.exceptions.InvalidMobileNumberException;
import com.cg.pizza.services.PizzaServices;
import com.cg.pizza.services.PizzaServicesImpl;

public class MainClass {
	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		main();
		int userChoice = sc.nextInt();
		getPizzaDeleiverySystemMainScreen(userChoice);
		
	}
	public static void main() {
		System.out.println("**********************************Welcome To BIGGIES Pizza********************************** ");
		System.out.println("Please Enter your choice:-");
		System.out.println("1. Register New Customer");
		System.out.println("2. Accept Order");
		System.out.println("3. View Menu ");
		System.out.println("4. View All Orders");
		System.out.println("5. View Order Details of Customer");
		System.out.println("6. Remove Cudtomers");
		System.out.println("7. View Customer Details");
		System.out.println("8. Exit");
	}
	
	public static void getPizzaDeleiverySystemMainScreen(int userChoice) {
		PizzaServices services = new PizzaServicesImpl();
		switch(userChoice)
		{
			case 1:
				try {
				System.out.println("Enter the name of customer:-");
				String firstName = sc.next();
				System.out.println("Enter the last name of customer:-");
				String lastName = sc.next();
				System.out.println("Enter the Mobile Number of Customer:-");
				String mobNumber = sc.next();
				System.out.println("Enter the e-mail Id of Customer:-");
				String emailId =sc.next();
				System.out.println("Enter the City of Customer:-");
				String city =  sc.next();
				System.out.println("Enter any Landmark:-");
				String landmark = sc.next();
				System.out.println("Enter the Pincode of area:-");
				long zipCode = sc.nextLong();
				int customerId=services.acceptCustomerDetails(firstName, lastName, mobNumber, emailId, city, landmark, zipCode);
				System.out.println("*****************************CLIENT REGISTERED*****************************");
				System.out.println("Customer ID is:-"+customerId);
				break;} 
				catch (InvalidMobileNumberException e) {
				e.printStackTrace();break;} 
				catch (InvalidEmailIdException e) {
				e.printStackTrace();break;}
				
			case 2:
				System.out.println("Enter the customer ID:-");
				
				services.acceptOrder(custId, null);
			case 3:
				orderMainMenu();break;
			case 4:
				
			case 5:
				
			case 6:
				
			case 7:
				
			case 8:System.exit(0);
				
			default:System.out.println("Sorry, Invalid selection. Please try again!!!!");
		}
		main(null);
	}
	private static void orderMainMenu() {
		System.out.println("1. Onion Pizza");
		System.out.println("2. Cheese Pizza");
		System.out.println("FarmHouse Pizza");
		System.out.println("Chicken Pizza");
		main(null);
	}

}
