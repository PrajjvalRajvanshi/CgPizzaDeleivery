package com.cg.pizza.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.util.PizzaDBUtil;


public class PizzaServicesDAOImpl implements PizzaDAO
{

	@Override
	public Customer save(Customer customer) {
		customer.setCustId(PizzaDBUtil.getCUSTOMER_ID());
		PizzaDBUtil.customer.put((long)customer.getCustId(), customer);
		return customer;
	}


	@Override
	public Customer findOne(long custId) {
		Customer customer = PizzaDBUtil.customer.get(custId);
		return customer;
	}

	@Override
	public List<Customer> findAll() {
		ArrayList allCustomerDetails = new ArrayList<>(PizzaDBUtil.customer.values());
		return allCustomerDetails;
	}


	@Override
	public boolean update(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

}
